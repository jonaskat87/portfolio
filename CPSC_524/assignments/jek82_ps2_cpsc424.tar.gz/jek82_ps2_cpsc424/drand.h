extern void dsrand(unsigned);
extern double drand(void);

