/* parallel Mandelbrot set code - using atomic with loop 
   functionality AND for using drand-ts-2.o. */

# include <stdlib.h>
# include <math.h>
# include "timing.h" // using provided timing routine
# include "drand.h" // using provided random number generator
# include <omp.h> // using OpenMP

int main() {
  int a,b,N; // number of horizontal elements, vertical elements, and iterations, respectively
  double h, wcTime_i, wcTime_f, cpuTime; // step size, wallclock time, end wallclock time, and cpu time, respectively

  // clear screen for input
  system("clear");
  // take user input for N
  scanf("%d", &N);
  // take user input for h
  scanf("%lf", &h);

  // compute a and b from h
  a = round((0.5 + 2.0) / h);
  b = round((1.25 - 0.0) / h);
  // check if h divides the dimensions properly. If not, return error
  if ( (a != ((0.5 + 2.0) / h)) || (b != ((1.25 - 0.0) / h)) ) {
      printf("Invalid user input for dx (should divide the side lengths of R). Aborted.\n");
      exit(-1);
  }

  /* no need to save virtual grid since we can just loop and count NI and NO
     directly now that we know a and b */
  timing(&wcTime_i, &cpuTime); // start times for routine
  int NI = 0; // initialize number of elements in the Mandelbrot set
  // private seed, which will be modified for each thread according to thread number
  int privseed = 12345;
  
  /* variables declared outside parallel region are implicitly shared and 
     those declared inside are implicitly private. */
  /* number of threads need not be declared here as it is already declared as
     an environment variable: OMP_NUM_THREADS. */
  #pragma omp parallel firstprivate(privseed) 
  {
    #pragma omp critical
    {
      privseed += omp_get_thread_num();
      dsrand(privseed); // set private seed according to thread number
    }
    double cx,cy; // real and imaginary parts of c, respectively
    double w, zx; // initial, final values of the real part of z, respectively
    double zy; // imaginary part of z
    int k; // map iteration counter
    // collapse 2 because there are two independent for loops
    #pragma omp for schedule(runtime) collapse(2) 
    for (int i = 0; i < a; ++i) {
      for (int j = 0; j < b; ++j) {
  	cx = (drand() + (double)i) * h - 2.0;
  	cy = (drand() + (double)j) * h;
  	zx = 0.0; // initialize zx
  	zy = 0.0; // initialize zy
  	k = 0; // initialize k
  	for ( ; k < N; ++k) {
  	  w = zx;
  	  zx = w * w - zy * zy + cx; // update real part
  	  zy = 2 * w * zy + cy; // update imaginary part
  	  /* check if |z| > 2 (or equivalently, |z| ** 2 > 4).
  	     If true, then break iteration and
  	     test a new value of c. */
  	  if ( zx * zx + zy * zy > 4.0 ) {
  	    break;
  	  }
  	}
  	// if |z| > 2 never reached, then increment NI
  	if ( k == N ) {
	  #pragma omp atomic
	  ++NI;
  	}
      }
    }
  }
  timing(&wcTime_f, &cpuTime); // end times for routine
  // print wallclock time elapsed for Monte Carlo area estimation
  double wcTime = wcTime_f - wcTime_i;
  printf("Wallclock time elapsed for algorithm was %lf s.\n", wcTime);
  // print area of Mandelbrot set
  // area of R is trivial, since rectangle
  /* a elements in horizontal dimension and b in vertical for rectangular 
     region, so we are testing a * b total values of c. Thus, if NI of 
     those are inside the Mandelbrot set, then NO is equal to...*/
  int NO = a * b - NI; 
  double area = 2.0 * (double)NI * (0.5 + 2.0) * (1.25 - 0.0) / ((double)(NI + NO));
  printf("Approximated area of the Mandelbrot Set is %.15lf.\n", area);
  return 0;
}
